<!DOCTYPE html>
<html lang="en">


<!-- voice-message.php   03:26:27 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/lightcase.css">
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/main.css">

    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">

    <title>Web Design Packages | Tech PMK - World Class IT Solutions</title>
	<meta name="keywords" content="IT Solutions for - Web Designing, Website Designing, TECHPMK, Tech PMK, Shared Hosting, Linux Unlimited Hosting, Hosting,  Domain Registration, Bulk SMS and Many More">
    <meta name="description" content="IT Solutions for - Web Designing, Shared Hosting, Domain Registration, Bulk SMS and Many More">
    <meta name="author" content="Tech PMK">


</head>

<body>
    <!-- ==========Preloader========== -->
    <div class="preloader">
        <div class="preloader-wrapper">
            <img src="assets/css/ajax-loader.gif" alt="ajax-loader">
        </div>
    </div>
    <!-- ==========Preloader========== -->
    <!-- ==========scrolltotop========== -->
    <a href="#0" class="scrollToTop">
        <img src="assets/images/rocket.png" alt="rocket">
    </a>
    <!-- ==========scrolltotop========== -->

    <!-- ==========Header Section========== -->
    <header>
        <div class="header-top d-none d-md-block bg-theme">
            <div class="container">
                <div class="header-top-wrapper">
                    <div class="row">
                        <div class="col-md-8">
                            <ul>
                                <li class="mr-3">
                                    <a href="Tel:+919476304518"><i class="fa fa-phone-square"></i>+91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="mailto:support@techpmk.in"><i class="fas fa-envelope"></i>support@techpmk.in</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-4 d-flex flex-wrap align-items-center justify-content-end">
                            <ul class="social">
                                <li>
                                    <a href="http://www.facebook.com/techpmk">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
								<li>
                                    <a href="https://wa.me/919476304518?text=Hello%2C%20I%20am%20from%20TECHPMK.IN%20-">
                                        <i class="fab fa-whatsapp"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.twitter.com/techpmk">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                </li>
                            </ul>
                           
					   </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom">
            <div class="container">
                <div class="header-area">
                    <div class="logo">
                        <a href="index.php"><img src="assets/images/logo/logo01.png" alt="logo"></a>
                    </div>
                    <ul class="menu">
					<li>
                            <a href="index.php">Home</a>
                    </li>
						<li>
                            <a href="#0">company Info</a>
                            <ul class="submenu">
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
                                                             
                                <li>
                                    <a href="team.php">Our Team</a>
                                </li>
								
								<li>
                                    <a href="bank.php">Bank Details</a>
                                </li>
								
								<li>
                                    <a href="testimonial.php">Testimonials</a>
                                </li>

								<li>
                                    <a href="#0">Carrier</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="carrier.php">Carrier Oppourtunity</a>
                                        </li>
										
										<li>
                                            <a href="carrrier-registration.php">Registration</a>
                                        </li>
                                                             </ul>
                                </li>								
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Domain</a>
                            <ul class="submenu">
                                <li>
                                    <a href="domain-register.php">Register Domain</a>
                                </li>
                                                             
                                <li>
                                    <a href="domain-transfer.php">Transfer Domain</a>
                                </li>
								<li>
                                    <a href="domain-price.php">Domain Price List</a>
                                </li>
							</ul>
                        </li>
						
						
						<li>
                            <a href="#0">Hosting</a>
                            <ul class="submenu">
                                <li>
                                    <a href="shared-hosting.php">Shared Hosting</a>
                                </li>
                                <li>
                                    <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                </li>
                                <li>
                                    <a href="reseller-hosting.php">Reseller Hosting</a>
                                </li>
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Bulk SMS</a>
                            <ul class="submenu">
                                <li>
                                    <a href="bulk-sms.php">Bulk SMS</a>
                                </li>
                                <li>
                                    <a href="sms-price.php">SMS Price List</a>
                                </li>
								<li>
                                    <a href="http://www.sms.techpmk.in"target="blank">SMS Panel Login</a>
                                </li>
								<li>
                                    <a href="sms-registration.php">SMS Registration</a>
                                </li>
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Services</a>
                            <ul class="submenu">
                                <li>
                                    <a href="services.php">All Services</a>
                                </li>
                                <li>
                                    <a href="web-design.php">Website Design </a>
                                </li>
                                <li>
                                    <a href="web-development.php">Website Development</a>
                                </li>
                                <li>
                                    <a href="ecommerce.php">e Commerce Website</a>
                                </li>
								<li>
                                    <a href="software.php">Software Development</a>
                                </li>
								<li>
                                    <a href="android.php">Android Application</a>
                                </li>
								<li>
                                    <a href="#0">SEO</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="seo.php">SEO</a>
                                        </li>
										
										<li>
                                            <a href="guest-posting.php">Guest Posting</a>
                                        </li>
										<li>
                                            <a href="sem.php">SEM</a>
                                        </li>
										
                                    </ul>
                                </li>
                                <li>
                                    <a href="#0">Domain</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="domain-register.php">Resigster a Domain</a>
                                        </li>
										
										<li>
                                            <a href="domain-transfer.php">Transfer a Domain</a>
                                        </li>
										<li>
                                            <a href="domain-price.php">Domain Price List</a>
                                        </li>
                                    </ul>
                                </li>
								<li>
                                    <a href="#0">Hosting</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="shared-hosting.php">Shared Hosting</a>
                                        </li>
										
										<li>
                                            <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                        </li>
										<li>
                                            <a href="reseller-hosting.php">Reseller Hosting</a>
                                        </li>
                                    </ul>
                                </li>	
								<li>
                                    <a href="#0">Bulk SMS</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="bulk-sms.php">Bulk SMS</a>
                                        </li>
										
										<li>
                                            <a href="sms-price.php">SMS Price</a>
                                        </li>
								    </ul>
                                </li>
									<li>
                                    <a href="#0">Digi Biz Card</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="digi-card.php">Digital Biz Card</a>
                                        </li>
										
										<li>
                                            <a href="digi-card-price.php">Price List</a>
                                        </li>
									</ul>
                                </li>								
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">My Digi Card</a>
                            <ul class="submenu">
                                <li>
                                    <a href="digi-card.php">About Digi Card</a>
                                </li>
                                <li>
                                    <a href="digi-card-price.php">Price List</a>
                                </li>
								
                            </ul>
                        </li>
						
						
                        
						
						<li>
                            <a href="#0">Packages</a>
                            <ul class="submenu">
                                <li>
                                    <a href="web-design-package.php">Web Design Packages</a>
                                </li>
                                <li>
                                    <a href="logo-desig-package.php">Logo Design Packages</a>
                                </li>
							</ul>
                        </li>
					
						<li>
                            <a href="contact.php">contact</a>
                        </li>
                    </ul>
                    <div class="header-bar d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                   
                           
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ==========Header Section========== -->

    <!-- =============Hero Area============= -->
    <section class="hero-area bg_img" data-background="assets/images/page-header.jpg">
        <div class="container">
            <h1 class="title m-0">Web Design Packages</h1>
        </div>
    </section>
    <div class="breadcrumb-section">
        <div class="container">
            <ul class="breadcrumb">
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>
                    Web Designing Packages
                </li>
            </ul>
        </div>
    </div>
    <!-- =============Hero Area============= -->

    <!--=================Voice Message================= -->
    <section class="voice-message padding-bottom padding-top">
        <div class="container">
            <div class="row justify-content-center mb-30-none">
			<!--Head Start-->
				<div class="col-sm-10 col-lg-12">
                    <div class="operator-item">
                        <h4 class="title">Our Designing Features</h4>
                    </div>
                </div>
				<!--HEAD End-->
                <div class="col-md-6 col-sm-10 col-lg-4">
                    <div class="contact-item">
                        <div class="contact-thumb">
                        <img src="./assets/images/web-design/our-approach.png" alt="contact">
                        </div>
                        <div class="contact-content">
                            <h4 class="title">Our approach</h4>
                            <ul>
                                <li>We take up projects with a pinch of realism. Be it in estimating
								the timeline, preparing the budget or architecting a complex solution. 
								You’ll never get a bloated project scope document, jargon filled proposals 
								or surprise clauses in our statement of work.</li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
				<div class="col-md-6 col-sm-10 col-lg-4">
                    <div class="contact-item">
                        <div class="contact-thumb">
                        <img src="./assets/images/web-design/our-experience.png" alt="contact">
                        </div>
                        <div class="contact-content">
                            <h4 class="title">Our experience</h4>
                            <ul>
                                <li>Everyone claims to be a digital media expert these days. How many of 
								them have the experience of working on the internet medium relentlessly 
								for the last 19 years? We do. And we’re waiting for the opportunity to 
								use this experience on your next project.</li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
				<div class="col-md-6 col-sm-10 col-lg-4">
                    <div class="contact-item">
                        <div class="contact-thumb">
                        <img src="./assets/images/web-design/focus.png" alt="contact">
                        </div>
                        <div class="contact-content">
                            <h4 class="title">Focus on quality</h4>
                            <ul>
                                <li>We believe our focus on quality deliverables is what brought us to where 
								we are now. All our projects go through different layers of testing and quality 
								assurance, to make sure that the final deliverable is free from issues and roadblocks!</li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
				<div class="col-md-6 col-sm-10 col-lg-4">
                    <div class="contact-item">
                        <div class="contact-thumb">
                        <img src="./assets/images/web-design/international.png" alt="contact">
                        </div>
                        <div class="contact-content">
                            <h4 class="title">International exposure</h4>
                            <ul>
                                <li>Our work spans mission-critical applications for top-tier enterprises, 
								international start-ups, ecommerce and audience engagement solutions for global 
								brands. Our outsourcing and custom software services are availed by customers from 
								across the world.</li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
				<div class="col-md-6 col-sm-10 col-lg-4">
                    <div class="contact-item">
                        <div class="contact-thumb">
                        <img src="./assets/images/web-design/one-roof.png" alt="contact">
                        </div>
                        <div class="contact-content">
                            <h4 class="title">One roof</h4>
                            <ul>
                                <li>From branding to digital, mobile, cloud and analytics, Niyati can 
								support your requirements with its in-house team of full-time professionals 
								and associates. Being a lean organization, you also get the individual 
								attention from the Senior members of the team on every project.</li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
				<div class="col-md-6 col-sm-10 col-lg-4">
                    <div class="contact-item">
                        <div class="contact-thumb">
                        <img src="./assets/images/web-design/extra-mile.png" alt="contact">
                        </div>
                        <div class="contact-content">
                            <h4 class="title">Going an extra mile</h4>
                            <ul>
                                <li>We believe in going that extra mile, beyond just design and development, 
								to make sure that your business has a reliable growth partner. We keep learning 
								more about your business as we keep discovering the different ways in which your
								audiences behave in the digital medium.</li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
			</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=================Voice Message================= -->
	
	<!--=================Price Plan================= -->
    <section class="price-section padding-top padding-bottom">
        <div class="container">
            <div class="section-header wow fadeInUp">
                <span class="cate">pricing plan</span>
                <h2 class="title">Our Designing Packages.</h2>
				<span class="cate">Easy EMI Option Available</span>
            </div>
            <div class="row mb-30-none justify-content-center">
                <div class="col-md-6 col-lg-4">
                    <div class="price-item wow fadeInUp" data-wow-delay=".3s">
                        <div class="price-header">
                            <span class="category">Package - ONE PAGE</span>
                            <h3 class="sub-title">&#8377; 2499/-</h3>
                            <p></p>
                            <h6> Easy EMI Option Available</h6>
                        </div>
						<ul>
						  <li>One Page Website</li>
						  <li>100% Responsive</li>
						  <li>Graphics & Animation</li>
						  <li>01 Form Submission</li>
						  <li>One Click WhatsApp</li>
						  <li>One Click E-Mail</li>
						  <li>Direct Dial</li>
						  <li>Google Map Integration</li>
						  <li>Social Media Integration</li>
						  <li>Search Engine Submission</li>
						  <li>Life Time Support.</li>
						  <li> </li>
						  <li> 
						   <a href="sign-up.php" class="custom-button">Order Now</a>
						  </li>
						 </ul>
					</div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="price-item wow fadeInUp" data-wow-delay=".3s">
                        <div class="price-header">
                            <span class="category">MERCURY</span>
                            <h3 class="sub-title">&#8377; 4999/-</h3>
							<p></p>
                            <h6> Easy EMI Option Available</h6>
                        </div>
						<ul>
						  <li>Total Page : 5</li>
						  <li>100% Responsive</li>
						  <li>Graphics & Animation</li>
						  <li>02 Form Submission</li>
						  <li>One Click WhatsApp</li>
						  <li>One Click E-Mail</li>
						  <li>Direct Dial</li>
						  <li>Social Media Integration</li>
						  <li>Google Map Integration</li>
						  <li>Search Engine Submission</li>
						  <li>Life Time Support.</li>
						  <li>40% Discount on Development</li>
						  <li> 
						   <a href="sign-up.php" class="custom-button">Order Now</a>
						  </li>
						 </ul>
					</div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="price-item wow fadeInUp" data-wow-delay=".3s">
                        <div class="price-header">
                            <span class="category">LEAD</span>
                            <h3 class="sub-title">&#8377; 6999/-</h3>
							<p></p>
                             <h6> Easy EMI Option Available</h6>
                        </div>
						<ul>
						  <li>Total Page : 10</li>
						  <li>100% Responsive</li>
						  <li>Graphics & Animation</li>
						  <li>03 Form Submission</li>
						  <li>One Click WhatsApp</li>
						  <li>One Click E-Mail</li>
						  <li>Direct Dial</li>
						  <li>Social Media Integration</li>
						  <li>Google Map Integration</li>
						  <li>Search Engine Submission</li>
						  <li>Life Time Support.</li>
						  <li>40% Discount on Development</li>
						  <li> 
						   <a href="sign-up.php" class="custom-button">Order Now</a>
						  </li>
						 </ul>
					</div>
                </div>
				<div class="col-md-6 col-lg-4">
                    <div class="price-item wow fadeInUp" data-wow-delay=".3s">
                        <div class="price-header">
                            <span class="category">SILICON</span>
                            <h3 class="sub-title">&#8377; 8999/-</h3>
							<p></p>
                             <h6> Easy EMI Option Available</h6>
                        </div>
						<ul>
						  <li>Total Page : 15</li>
						  <li>100% Responsive</li>
						  <li>Graphics & Animation</li>
						  <li>05 Form Submission</li>
						  <li>One Click WhatsApp</li>
						  <li>One Click E-Mail</li>
						  <li>Direct Dial</li>
						  <li>Social Media Integration</li>
						  <li>Google Map Integration</li>
						  <li>Search Engine Submission</li>
						  <li>Life Time Support.</li>
						  <li>40% Discount on Development</li>
						  <li> 
						   <a href="sign-up.php" class="custom-button">Order Now</a>
						  </li>
						 </ul>
					</div>
                </div>
				<div class="col-md-6 col-lg-4">
                    <div class="price-item wow fadeInUp" data-wow-delay=".3s">
                        <div class="price-header">
                            <span class="category">DIAMOND</span>
                            <h3 class="sub-title">&#8377; 13499/-</h3>
							<p></p>
                             <h6> Easy EMI Option Available</h6>
                        </div>
						<ul>
						  <li>Total Page : 20</li>
						  <li>100% Responsive</li>
						  <li>Graphics & Animation</li>
						  <li>03 Form Submission</li>
						  <li>One Click WhatsApp</li>
						  <li>One Click E-Mail</li>
						  <li>Direct Dial</li>
						  <li>Google Map Integration</li>
						  <li>Live Chat Integration</li>
						  <li>Social Media Integration</li>
						  <li>1 Logo Design</li>
						  <li>Search Engine Submission</li>
						  <li>Life Time Support.</li>
						  <li>40% Discount on Development</li>
						  <li> 
						   <a href="sign-up.php" class="custom-button">Order Now</a>
						  </li>
						 </ul>
					</div>
                </div>
				<div class="col-md-6 col-lg-4">
                    <div class="price-item wow fadeInUp" data-wow-delay=".3s">
                        <div class="price-header">
                            <span class="category">ENTERPRISE</span>
                            <h3 class="sub-title">&#8377; 24999/-</h3>
							<p></p>
                             <h6> Easy EMI Option Available</h6>
                        </div>
						<ul>
						  <li>Unlimited Pages</li>
						  <li>Free 1 Domain</li>
						  <li>Free Unlimited Hosting for First 03 Months</li>
						  <li>100% Responsive</li>
						  <li>Graphics & Animation</li>
						  <li>Unlimited  Form Submission</li>
						  <li>One Click WhatsApp</li>
						  <li>One Click E-Mail</li>
						  <li>Direct Dial</li>
						  <li>Basic Android Application</li>
						  <li>Live Chat Integration</li>
						  <li>Payment Gateway</li>
						  <li>1 Logo Design</li>
						  <li>Social Media Integration</li>
						  <li>Search Engine Submission</li>
						  <li>Free SEO for first 30 Days</li>
						  <li>Life Time Support.</li>
						  <li>40% Discount on Development</li>
						  <li> 
						   <a href="sign-up.php" class="custom-button">Order Now</a>
						  </li>
						 </ul>
					</div>
                </div>
				<div class="col-md-6 col-lg-6">
                    <div class="price-item wow fadeInUp" data-wow-delay=".3s">
                        <div class="price-header">
                            <span class="category">CUSTOMISE PLAN</span>
							 <h6>Each Parts has individual Price</h6>
                            <h3 class="sub-title">&#8377; 2999/-</h3>
                            <p>Basic Price for this Packages</p>
							<p></p>
                             <h6> Easy EMI Option Available</h6>
                        </div>
						<ul>
						  <li><u> Basic Design Features</u></li>
						  <li>Home & Contact Page</li>
						  <li>100% Responsive</li>
						  <li>Graphics & Animation</li>
						  <li>01 Form Submission</li>
						  <li>One Click WhatsApp</li>
						  <li>One Click E-Mail</li>
						  <li>Direct Dial</li>
						  <li>Search Engine Submission</li>
						  <li><u><h4>Details Price</h4></u></li>
						  <li>Per Page Design: Rs. 500/-</li>
						  <li>Per Form Submission : Rs. 200/-</li>
						  <li>Google Map Integration : Rs. 300/-</li>
						  <li>Live Chat Integration : Rs. 300/-</li>
						  <li>Payment Gateway : Rs. 999/-</li>
						  <li>Social Activities Price : Rs. 500/-</li>
						  <li>Logo Design <br> (2 Times Modification): Rs. 500/-</li>
						  <li> 
						   <a href="sign-up.php" class="custom-button">Order Now</a>
						  </li>
						 </ul>
					</div>
                </div>
            </div>
        </div>
    </section>
    <!--=================Price Plan================= -->

    

    <!--=================Footer Section================= -->
    <footer>
        <div class="footer-top padding-top padding-bottom">
            <div class="container">
                <div class="row mb-50-none">
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Services</h5>
                            <ul>
                                <li>
                                    <a href="domain-register.php">Register Domain</a>
                                </li>
                                <li>
                                    <a href="shared-hosting.php">Shared Hosting</a>
                                </li>
                                <li>
                                    <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                </li>
                                <li>
                                    <a href="bulk-sms.php">Bulk SMS</a>
                                </li>
                                <li>
                                    <a href="web-design-package.php">Web Design Packages</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Company Info</h5>
                            <ul>
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
								<li>
                                    <a href="privacy.php">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="bank.php">Payment Gateway</a>
                                </li>
                                <li>
                                    <a href="faq.php">FAQ</a>
                                </li>
                                <li>
                                    <a href="http://tawk.to/techpmk"target="blank">Support</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Contact</h5>
                            <ul>
                                <li>
                                    <a href="tel:+919476304518">Call : +91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="http://wa.me/919476304518">Whatsapp : +91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="mailto:support@techpmk">Mail : support@techpmk.in</a>
                                </li>	
								<li>
                                    <a href="https://tawk.to/techpmk"target="blank">Live Chat</a>
                                </li>
								<li>
                                    <a href="https://techpmk.onlineinvoices.com/"target="blank">Login to Billing Section</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-about">
                            <h5 class="title">about us</h5>
                            <p align="justify">Tech PMK is the web & graphic designing Organization of India, doing world-class IT solutions. </p>
                            <ul class="footer-social">
                                <li>
                                    <a href="http://www.facebook.com/techpmk"target="blank"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.twitter.com/techpmk"target="blank"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#0"><i class="fab fa-instagram"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.skype.com/techpmk"target="blank"><i class="fab fa-skype"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom py-3 py-sm-4 text-center">
            <div class="container">
                <p class="m-0"> <a href="index.php"><i class="fa fa-copyright"></i> 2020 - All right reserved. | Tech PMK - World Class IT Solutions</a></p>
            </div>
        </div>
    </footer>
    <!--=================Footer Section================= -->
	<!-- ================ Start WhatsApp Widget ================= -->

<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+919476304518", // WhatsApp number
            call_to_action: "Whatsapp us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>

<!-- ================ End WhatsApp Widget ================= -->

    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/waypoint.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/lightcase.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/counterup.min.js"></script>
    <script src="assets/js/nice-select.js"></script>
    <script src="assets/js/main.js"></script>
</body>


<!-- voice-message.php   03:26:33 GMT -->
</html>