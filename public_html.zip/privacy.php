<!DOCTYPE html>
<html lang="en">


<!-- privacy.php   03:25:50 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/lightcase.css">
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/main.css">

    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">

    <title>Privacy Policy | Tech PMK - World Class IT Solutions</title>
	<meta name="keywords" content="IT Solutions for - Web Designing, Website Designing, TECHPMK, Tech PMK, Shared Hosting, Linux Unlimited Hosting, Hosting,  Domain Registration, Bulk SMS and Many More">
    <meta name="description" content="IT Solutions for - Web Designing, Shared Hosting, Domain Registration, Bulk SMS and Many More">
    <meta name="author" content="Tech PMK">


</head>

<body data-spy="scroll" data-offset="170" data-target=".privacy-sidebar-content">
    <!-- ==========Preloader========== -->
    <div class="preloader">
        <div class="preloader-wrapper">
            <img src="assets/css/ajax-loader.gif" alt="ajax-loader">
        </div>
    </div>
    <!-- ==========Preloader========== -->
    <!-- ==========scrolltotop========== -->
    <a href="#0" class="scrollToTop">
        <img src="assets/images/rocket.png" alt="rocket">
    </a>
    <!-- ==========scrolltotop========== -->

    <!-- ==========Header Section========== -->
    <header>
        <div class="header-top d-none d-md-block bg-theme">
            <div class="container">
                <div class="header-top-wrapper">
                    <div class="row">
                        <div class="col-md-8">
                            <ul>
                                <li class="mr-3">
                                    <a href="Tel:+919476304518"><i class="fa fa-phone-square"></i>+91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="mailto:support@techpmk.in"><i class="fas fa-envelope"></i>support@techpmk.in</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-4 d-flex flex-wrap align-items-center justify-content-end">
                            <ul class="social">
                                <li>
                                    <a href="http://www.facebook.com/techpmk">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
								<li>
                                    <a href="https://wa.me/919476304518?text=Hello%2C%20I%20am%20from%20TECHPMK.IN%20-">
                                        <i class="fab fa-whatsapp"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.twitter.com/techpmk">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                </li>
                            </ul>
                           
					   </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom">
            <div class="container">
                <div class="header-area">
                    <div class="logo">
                        <a href="index.php"><img src="assets/images/logo/logo01.png" alt="logo"></a>
                    </div>
                    <ul class="menu">
					<li>
                            <a href="index.php">Home</a>
                    </li>
						<li>
                            <a href="#0">company Info</a>
                            <ul class="submenu">
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
                                                             
                                <li>
                                    <a href="team.php">Our Team</a>
                                </li>
								
								<li>
                                    <a href="bank.php">Bank Details</a>
                                </li>
								
								<li>
                                    <a href="testimonial.php">Testimonials</a>
                                </li>

								<li>
                                    <a href="#0">Carrier</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="carrier.php">Carrier Oppourtunity</a>
                                        </li>
										
										<li>
                                            <a href="carrrier-registration.php">Registration</a>
                                        </li>
                                                             </ul>
                                </li>								
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Domain</a>
                            <ul class="submenu">
                                <li>
                                    <a href="domain-register.php">Register Domain</a>
                                </li>
                                                             
                                <li>
                                    <a href="domain-transfer.php">Transfer Domain</a>
                                </li>
								<li>
                                    <a href="domain-price.php">Domain Price List</a>
                                </li>
							</ul>
                        </li>
						
						
						<li>
                            <a href="#0">Hosting</a>
                            <ul class="submenu">
                                <li>
                                    <a href="shared-hosting.php">Shared Hosting</a>
                                </li>
                                <li>
                                    <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                </li>
                                <li>
                                    <a href="reseller-hosting.php">Reseller Hosting</a>
                                </li>
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Bulk SMS</a>
                            <ul class="submenu">
                                <li>
                                    <a href="bulk-sms.php">Bulk SMS</a>
                                </li>
                                <li>
                                    <a href="sms-price.php">SMS Price List</a>
                                </li>
								<li>
                                    <a href="http://www.sms.techpmk.in"target="blank">SMS Panel Login</a>
                                </li>
								<li>
                                    <a href="sms-registration.php">SMS Registration</a>
                                </li>
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Services</a>
                            <ul class="submenu">
                                <li>
                                    <a href="services.php">All Services</a>
                                </li>
                                <li>
                                    <a href="web-design.php">Website Design </a>
                                </li>
                                <li>
                                    <a href="web-development.php">Website Development</a>
                                </li>
                                <li>
                                    <a href="ecommerce.php">e Commerce Website</a>
                                </li>
								<li>
                                    <a href="software.php">Software Development</a>
                                </li>
								<li>
                                    <a href="android.php">Android Application</a>
                                </li>
								<li>
                                    <a href="#0">SEO</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="seo.php">SEO</a>
                                        </li>
										
										<li>
                                            <a href="guest-posting.php">Guest Posting</a>
                                        </li>
										<li>
                                            <a href="sem.php">SEM</a>
                                        </li>
										
                                    </ul>
                                </li>
                                <li>
                                    <a href="#0">Domain</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="domain-register.php">Resigster a Domain</a>
                                        </li>
										
										<li>
                                            <a href="domain-transfer.php">Transfer a Domain</a>
                                        </li>
										<li>
                                            <a href="domain-price.php">Domain Price List</a>
                                        </li>
                                    </ul>
                                </li>
								<li>
                                    <a href="#0">Hosting</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="shared-hosting.php">Shared Hosting</a>
                                        </li>
										
										<li>
                                            <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                        </li>
										<li>
                                            <a href="reseller-hosting.php">Reseller Hosting</a>
                                        </li>
                                    </ul>
                                </li>	
								<li>
                                    <a href="#0">Bulk SMS</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="bulk-sms.php">Bulk SMS</a>
                                        </li>
										
										<li>
                                            <a href="sms-price.php">SMS Price</a>
                                        </li>
								    </ul>
                                </li>
									<li>
                                    <a href="#0">Digi Biz Card</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="digi-card.php">Digital Biz Card</a>
                                        </li>
										
										<li>
                                            <a href="digi-card-price.php">Price List</a>
                                        </li>
									</ul>
                                </li>								
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">My Digi Card</a>
                            <ul class="submenu">
                                <li>
                                    <a href="digi-card.php">About Digi Card</a>
                                </li>
                                <li>
                                    <a href="digi-card-price.php">Price List</a>
                                </li>
								
                            </ul>
                        </li>
						
						
                        
						
						<li>
                            <a href="#0">Packages</a>
                            <ul class="submenu">
                                <li>
                                    <a href="web-design-package.php">Web Design Packages</a>
                                </li>
                                <li>
                                    <a href="logo-desig-package.php">Logo Design Packages</a>
                                </li>
							</ul>
                        </li>
					
						<li>
                            <a href="contact.php">contact</a>
                        </li>
                    </ul>
                    <div class="header-bar d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                   <div class="d-flex select-career justify-content-end">
                           
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ==========Header Section========== -->

    <!-- =============Hero Area============= -->
    <section class="hero-area bg_img" data-background="assets/images/page-header.jpg">
        <div class="container">
            <h1 class="title m-0">Privacy Policy</h1>
        </div>
    </section>
    <div class="breadcrumb-section">
        <div class="container">
            <ul class="breadcrumb">
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>
                    <a href="service.php">Service</a>
                </li>
                <li>
                    Privacy Policy
                </li>
            </ul>
        </div>
    </div>
    <!-- =============Hero Area============= -->
    
	
    <section class="privacy-section padding-top padding-bottom">
        <div class="container">
		<div class="video-content">
                <h2 class="title">Privacy Policy</h2>
				
                <p align="justify">At www.techpmk.in, accessible from https://www.techpmk.in, one of our main 
				priorities is the privacy of our visitors. This Privacy Policy document contains 
				types of information that is collected and recorded by www.techpmk.in and how we use it.</p>
				
				<p align="justify">If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.</p>
				
				<p align="justify">This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards 
				to the information that they shared and/or collect in www.techpmk.in. This policy is not applicable to any information collected 
				offline or via channels other than this website.</p>
				
				<p align="justify">This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards 
				to the information that they shared and/or collect in www.techpmk.in. This policy is not applicable to any information collected 
				offline or via channels other than this website.</p>
				
				<h3 class="title">Consent</h3>
				
				<p align="justify">By using our website, you hereby consent to our Privacy Policy and agree to its terms.</p>
				
				<h3 class="title">Information we collect</h3>
				
				<p align="justify">The personal information that you are asked to provide, and the reasons why you are asked to provide it, 
				will be made clear to you at the point we ask you to provide your personal information.</p>	
				
				<p align="justify">If you contact us directly, we may receive additional information about you such as your name, email address, 
				phone number, the contents of the message and/or attachments you may send us, and any other information you may choose to provide.</p>	
				
				<p align="justify">When you register for an Account, we may ask for your contact information, including items such as name, company name,
				address, email address, and telephone number.</p>
				
				<h3 class="title">How we use your information</h3>
				<p align="justify">We use the information we collect in various ways, including to:
				<li>Provide, operate, and maintain our webste </li>
				<li>Provide, operate, and maintain our webste </li>
				<li>Understand and analyze how you use our webste </li>
				<li>Develop new products, services, features, and functionality </li>
				<li>Communicate with you, either directly or through one of our partners, including for customer service, 
				to provide you with updates and other information relating to the webste, and for marketing and promotional purposes</li>
				<li>Send you emails</li>
				<li>Find and prevent fraud </li> </p>
				
				<h3 class="title">Log Files</h3>
				
				<p align="justify">www.techpmk.in follows a standard procedure of using log files. These files log visitors when they 
				visit websites. All hosting companies do this and a part of hosting services' analytics. The information collected by
				log files include internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp,
				referring/exit pages, and possibly the number of clicks. These are not linked to any information that is personally identifiable. 
				The purpose of the information is for analyzing trends, administering the site, tracking users' movement on the website, and gathering
				demographic information. Our Privacy Policy was created with the help of the Privacy Policy Generator and the Disclaimer Generator. </p>
				
				<h3 class="title">Cookies and Web Beacons</h3>
				
				<p align="justify">Like any other website, www.techpmk.in uses 'cookies'. These cookies are used to store information including visitors'
				preferences, and the pages on the website that the visitor accessed or visited. The information is used to optimize the users' experience 
				by customizing our web page content based on visitors' browser type and/or other information. </p>
				
				<p align="justify">For more general information on cookies, please read <a href="https://www.cookieconsent.com/what-are-cookies/">"What Are Cookies"</a>.</p>
				
				<h3 class="title">Advertising Partners Privacy Policies</h3>
				<p align="justify">You may consult this list to find the Privacy Policy for each of the advertising partners of www.techpmk.in. </p>
				
				<p align="justify">Third-party ad servers or ad networks uses technologies like cookies, JavaScript, or Web Beacons that are used in 
				their respective advertisements and links that appear on www.techpmk.in, which are sent directly to users' browser. They automatically receive your
				IP address when this occurs. These technologies are used to measure the effectiveness of their advertising campaigns and/or to personalize the advertising 
				content that you see on websites that you visit. </p>
				
				<p align="justify">Note that www.techpmk.in has no access to or control over these cookies that are used by third-party advertisers.</p>
				
				<h3 class="title">Third Party Privacy Policies</h3>
				<p align="justify">www.techpmk.in's Privacy Policy does not apply to other advertisers or websites. Thus, we are advising you to consult the
				respective Privacy Policies of these third-party ad servers for more detailed information. It may include their practices and instructions about how 
				to opt-out of certain options. You may find a complete list of these Privacy Policies and their links here: Privacy Policy Links. <br> You can choose to
				disable cookies through your individual browser options. To know more detailed information about cookie management with specific web browsers,
				it can be found at the browsers' respective websites. </p>
				
				<h3 class="title">CCPA Privacy Rights (Do Not Sell My Personal Information)</h3>
				<p align="justify">Under the CCPA, among other rights, California consumers have the right to: <br>
				Request that a business that collects a consumer's personal data disclose the categories and specific pieces of personal data that a business has collected
				about consumers. <br>
				Request that a business delete any personal data about the consumer that a business has collected. <br>
				Request that a business that sells a consumer's personal data, not sell the consumer's personal data. <br>
				If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us. </p>
				
				<h3 class="title">GDPR Data Protection Rights</h3>
				
				<p align="justify">We would like to make sure you are fully aware of all of your data protection rights. Every user is entitled to the following:<br>
				The right to access – You have the right to request copies of your personal data. We may charge you a small fee for this service.<br>
				The right to rectification – You have the right to request that we correct any information you believe is inaccurate. You also have the right to 
				request that we complete the information you believe is incomplete. <br>
				The right to erasure – You have the right to request that we erase your personal data, under certain conditions. <br>
				The right to restrict processing – You have the right to request that we restrict the processing of your personal data, under certain conditions. <br>
				The right to object to processing – You have the right to object to our processing of your personal data, under certain conditions. <br>
				The right to data portability – You have the right to request that we transfer the data that we have collected to another organization, 
				or directly to you, under certain conditions. <br>
				If you make a request, we have one month to respond to you. If you would like to exercise any of these rights, please contact us. </p>
				
				<h3 class="title">Children's Information</h3>
				
				<p align="justify">Another part of our priority is adding protection for children while using the internet. We encourage parents and guardians to observe, 
				participate in, and/or monitor and guide their online activity. <br>
				www.techpmk.in does not knowingly collect any Personal Identifiable Information from children under the age of 13. If you think that your child provided 
				this kind of information on our website, we strongly encourage you to contact us immediately and we will do our best efforts to promptly remove such 
				information from our records. </p>






				
            </div>
			
            
        </div>
    </section>
    <!--=================Footer Section================= -->
    <footer>
        <div class="footer-top padding-top padding-bottom">
            <div class="container">
                <div class="row mb-50-none">
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Services</h5>
                            <ul>
                                <li>
                                    <a href="domain-register.php">Register Domain</a>
                                </li>
                                <li>
                                    <a href="shared-hosting.php">Shared Hosting</a>
                                </li>
                                <li>
                                    <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                </li>
                                <li>
                                    <a href="bulk-sms.php">Bulk SMS</a>
                                </li>
                                <li>
                                    <a href="web-design-package.php">Web Design Packages</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Company Info</h5>
                            <ul>
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
								<li>
                                    <a href="privacy.php">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="bank.php">Payment Gateway</a>
                                </li>
                                <li>
                                    <a href="faq.php">FAQ</a>
                                </li>
                                <li>
                                    <a href="http://tawk.to/techpmk"target="blank">Support</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Contact</h5>
                            <ul>
                                <li>
                                    <a href="tel:+919476304518">Call : +91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="http://wa.me/919476304518">Whatsapp : +91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="mailto:support@techpmk">Mail : support@techpmk.in</a>
                                </li>	
								<li>
                                    <a href="https://tawk.to/techpmk"target="blank">Live Chat</a>
                                </li>
								<li>
                                    <a href="https://techpmk.onlineinvoices.com/"target="blank">Login to Billing Section</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-about">
                            <h5 class="title">about us</h5>
                            <p align="justify">Tech PMK is the web & graphic designing Organization of India, doing world-class IT solutions. </p>
                            <ul class="footer-social">
                                <li>
                                    <a href="http://www.facebook.com/techpmk"target="blank"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.twitter.com/techpmk"target="blank"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#0"><i class="fab fa-instagram"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.skype.com/techpmk"target="blank"><i class="fab fa-skype"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom py-3 py-sm-4 text-center">
            <div class="container">
                <p class="m-0"> <a href="index.php"><i class="fa fa-copyright"></i> 2020 - All right reserved. | Tech PMK - World Class IT Solutions</a></p>
            </div>
        </div>
    </footer>
    <!--=================Footer Section================= -->
	<!-- ================ Start WhatsApp Widget ================= -->

<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+919476304518", // WhatsApp number
            call_to_action: "Whatsapp us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>

<!-- ================ End WhatsApp Widget ================= -->

    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/waypoint.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/lightcase.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/counterup.min.js"></script>
    <script src="assets/js/nice-select.js"></script>
    <script src="assets/js/main.js"></script>
</body>


<!-- privacy.php   03:25:50 GMT -->
</html>