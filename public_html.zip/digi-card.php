<!DOCTYPE html>
<html lang="en">


<!-- about.php   03:24:22 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/lightcase.css">
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/main.css">

    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">

    <title>My Digital Business Card | Tech PMK - World Class IT Solutions</title>
	<meta name="keywords" content="IT Solutions for - Web Designing, Website Designing, TECHPMK, Tech PMK, Shared Hosting, Linux Unlimited Hosting, Hosting,  Domain Registration, Bulk SMS and Many More">
    <meta name="description" content="IT Solutions for - Web Designing, Shared Hosting, Domain Registration, Bulk SMS and Many More">
    <meta name="author" content="Tech PMK">



</head>	

<body>
    <!-- ==========Preloader========== -->
    <div class="preloader">
        <div class="preloader-wrapper">
            <img src="assets/css/ajax-loader.gif" alt="ajax-loader">
        </div>
    </div>
    <!-- ==========Preloader========== -->
    <!-- ==========scrolltotop========== -->
    <a href="#0" class="scrollToTop">
        <img src="assets/images/rocket.png" alt="rocket">
    </a>
    <!-- ==========scrolltotop========== -->

    <!-- ==========Header Section========== -->
    <header>
        <div class="header-top d-none d-md-block bg-theme">
            <div class="container">
                <div class="header-top-wrapper">
                    <div class="row">
                        <div class="col-md-8">
                            <ul>
                                <li class="mr-3">
                                    <a href="Tel:+919476304518"><i class="fa fa-phone-square"></i>+91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="mailto:support@techpmk.in"><i class="fas fa-envelope"></i>support@techpmk.in</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-4 d-flex flex-wrap align-items-center justify-content-end">
                            <ul class="social">
                                <li>
                                    <a href="http://www.facebook.com/techpmk">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
								<li>
                                    <a href="https://wa.me/919476304518?text=Hello%2C%20I%20am%20from%20TECHPMK.IN%20-">
                                        <i class="fab fa-whatsapp"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.twitter.com/techpmk">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                </li>
                            </ul>
                           
					   </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom">
            <div class="container">
                <div class="header-area">
                    <div class="logo">
                        <a href="index.php"><img src="assets/images/logo/logo01.png" alt="logo"></a>
                    </div>
                    <ul class="menu">
					<li>
                            <a href="index.php">Home</a>
                    </li>
						<li>
                            <a href="#0">company Info</a>
                            <ul class="submenu">
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
                                                             
                                <li>
                                    <a href="team.php">Our Team</a>
                                </li>
								
								<li>
                                    <a href="bank.php">Bank Details</a>
                                </li>
								
								<li>
                                    <a href="testimonial.php">Testimonials</a>
                                </li>

								<li>
                                    <a href="#0">Carrier</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="carrier.php">Carrier Oppourtunity</a>
                                        </li>
										
										<li>
                                            <a href="carrrier-registration.php">Registration</a>
                                        </li>
                                                             </ul>
                                </li>								
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Domain</a>
                            <ul class="submenu">
                                <li>
                                    <a href="domain-register.php">Register Domain</a>
                                </li>
                                                             
                                <li>
                                    <a href="domain-transfer.php">Transfer Domain</a>
                                </li>
								<li>
                                    <a href="domain-price.php">Domain Price List</a>
                                </li>
							</ul>
                        </li>
						
						
						<li>
                            <a href="#0">Hosting</a>
                            <ul class="submenu">
                                <li>
                                    <a href="shared-hosting.php">Shared Hosting</a>
                                </li>
                                <li>
                                    <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                </li>
                                <li>
                                    <a href="reseller-hosting.php">Reseller Hosting</a>
                                </li>
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Bulk SMS</a>
                            <ul class="submenu">
                                <li>
                                    <a href="bulk-sms.php">Bulk SMS</a>
                                </li>
                                <li>
                                    <a href="sms-price.php">SMS Price List</a>
                                </li>
								<li>
                                    <a href="http://www.sms.techpmk.in"target="blank">SMS Panel Login</a>
                                </li>
								<li>
                                    <a href="sms-registration.php">SMS Registration</a>
                                </li>
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Services</a>
                            <ul class="submenu">
                                <li>
                                    <a href="services.php">All Services</a>
                                </li>
                                <li>
                                    <a href="web-design.php">Website Design </a>
                                </li>
                                <li>
                                    <a href="web-development.php">Website Development</a>
                                </li>
                                <li>
                                    <a href="ecommerce.php">e Commerce Website</a>
                                </li>
								<li>
                                    <a href="software.php">Software Development</a>
                                </li>
								<li>
                                    <a href="android.php">Android Application</a>
                                </li>
								<li>
                                    <a href="#0">SEO</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="seo.php">SEO</a>
                                        </li>
										
										<li>
                                            <a href="guest-posting.php">Guest Posting</a>
                                        </li>
										<li>
                                            <a href="sem.php">SEM</a>
                                        </li>
										
                                    </ul>
                                </li>
                                <li>
                                    <a href="#0">Domain</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="domain-register.php">Resigster a Domain</a>
                                        </li>
										
										<li>
                                            <a href="domain-transfer.php">Transfer a Domain</a>
                                        </li>
										<li>
                                            <a href="domain-price.php">Domain Price List</a>
                                        </li>
                                    </ul>
                                </li>
								<li>
                                    <a href="#0">Hosting</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="shared-hosting.php">Shared Hosting</a>
                                        </li>
										
										<li>
                                            <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                        </li>
										<li>
                                            <a href="reseller-hosting.php">Reseller Hosting</a>
                                        </li>
                                    </ul>
                                </li>	
								<li>
                                    <a href="#0">Bulk SMS</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="bulk-sms.php">Bulk SMS</a>
                                        </li>
										
										<li>
                                            <a href="sms-price.php">SMS Price</a>
                                        </li>
								    </ul>
                                </li>
									<li>
                                    <a href="#0">Digi Biz Card</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="digi-card.php">Digital Biz Card</a>
                                        </li>
										
										<li>
                                            <a href="digi-card-price.php">Price List</a>
                                        </li>
									</ul>
                                </li>								
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">My Digi Card</a>
                            <ul class="submenu">
                                <li>
                                    <a href="digi-card.php">About Digi Card</a>
                                </li>
                                <li>
                                    <a href="digi-card-price.php">Price List</a>
                                </li>
								
                            </ul>
                        </li>
						
						
                        
						
						<li>
                            <a href="#0">Packages</a>
                            <ul class="submenu">
                                <li>
                                    <a href="web-design-package.php">Web Design Packages</a>
                                </li>
                                <li>
                                    <a href="logo-desig-package.php">Logo Design Packages</a>
                                </li>
							</ul>
                        </li>
					
						<li>
                            <a href="contact.php">contact</a>
                        </li>
                    </ul>
                    <div class="header-bar d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                   
                           
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ==========Header Section========== -->

    <!-- =============Hero Area============= -->
    <section class="hero-area bg_img" data-background="assets/images/page-header.jpg">
        <div class="container">
            <h1 class="title m-0">Digital Business Card</h1>
        </div>
    </section>
    <div class="breadcrumb-section">
        <div class="container">
            <ul class="breadcrumb">
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>
                    My Digital Business Card
                </li>
            </ul>
        </div>
    </div>
    <!-- =============Hero Area============= -->

    <!--=================About Us================= -->
    <section class="bulk-sms padding-top padding-bottom">
        <div class="container">
            <div class="row flex-wrap-reverse align-items-center">
                <div class="col-lg-6">
                    <div class="bulk-content text-center text-sm-left">
                        <h2 class="title">DIGITAL BUSINESS CARD</h2>
                        <span>GO PAPERLESS GO DIGITAL</span>
                        <p align="justify">Business cards are quite a pain to carry around.You never 
						quite know how many to bring along to a meeting or a work-related event. 
						And there’s that awkward moment mid-handshake when you’ve realized that 
						you’re out of business cards.Despite all the fuss, business cards still 
						remain a great tool for exchanging contact information. But can we do this 
						without needing physical business cards? Yes, in this digital era we have a 
						great solution for it, Digital Business Card help you to create your digital 
						identity where you can hand out it every where digitally.</p>
						<a href="assets/images/businesscard/demo/index.php"target="blank" class="custom-button">View Demo</a>
						
					</div>
                </div>
                <div class="col-lg-6">
                    <div class="bulk-thumb">
                        <img src="assets/images/businesscard/digi01.png" alt="Biz Card">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=================About Us================= -->

    <!-- ==============features Section============== -->
    <section class="operator-section padding-bottom padding-top">
        <div class="container">
            <div class="row justify-content-center mb-30-none">
                <!--Head Start-->
				<div class="col-sm-10 col-lg-12">
                    <div class="operator-item">
                        <h4 class="title">Features of Digital Business Card</h4>
                    </div>
                </div>
				<!--HEAD End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/whatsapp.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Direct Whatsapp</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/call.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Direct Call</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/messenger.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Direct Messenger</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/gmail.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Direct E-Mail</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/facebook.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Direct FB </h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/youtube.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Youtube Video</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/gallery.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Share Images</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/video.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Share Video</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/map.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Share Live Location</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/pdf.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Share Documents</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/bank.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Share Bank Details</h6>
                    </div>
                </div>
				<!--Features End-->
				<!--Features Start-->
				<div class="col-sm-5 col-lg-2">
                    <div class="operator-item">
                        <div class="operator-thumb">
                            <a href="#0">
                                <img src="assets/images/businesscard/QR.PNG" alt="operator">
                            </a>
                        </div>
                        <h6>Share  by QR Code</h6>
                    </div>
                </div>
				<!--Features End-->
		</div>
        </div>
    </section>
    <!-- ==============features Section============== -->
	
	<!--=================Features Stat================= -->
    <section class="faq-section padding-top padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="faq-area">
                        <h3 class="main-title">Benefit's of Digital Business Card</h3>
                        <div class="faq-wrapper">
                            <div class="faq-item open active">
                                <div class="faq-title">
                                    <h6 class="title">Share Your Digital Card by Link or QR Code.</h6>
                                    <span class="right-icon"></span>
                                </div>
                                <div class="faq-content">
                                    <p>You can share your Biz card link through QR Code or Link.</p>
                                </div>
                            </div>
                            <div class="faq-item">
                                <div class="faq-title">
                                    <h6 class="title">Don't need to carry Printed Visiting Card</h6>
                                    <span class="right-icon"></span>
                                </div>
                                <div class="faq-content">
                                    <p>Go Paperless, Go Digital. Just Share your link to your Client.</p>
                                </div>
                            </div>
                            <div class="faq-item">
                                <div class="faq-title">
                                    <h6 class="title">Easy to Share Product Details</h6>
                                    <span class="right-icon"></span>
                                </div>
                                <div class="faq-content">
                                    <p>There have every things are digital. so you can easily share your product details digitally.</p>
                                </div>
                            </div>
                            <div class="faq-item">
                                <div class="faq-title">
                                    <h6 class="title">Easy to Share Company Portfolio.</h6>
                                    <span class="right-icon"></span>
                                </div>
                                <div class="faq-content">
                                    <p>you are able to upload PDF document in your Card. So by that document you can share your company brochure or others documents to clients.</p>
                                </div>
                            </div>
							<div class="faq-item">
                                <div class="faq-title">
                                    <h6 class="title">Easy to Share Bank details of Payment Gateway.</h6>
                                    <span class="right-icon"></span>
                                </div>
                                <div class="faq-content">
                                    <p>You can Integrate Online Payment Gateway on your biz card. and share with your clients.</p>
                                </div>
                            </div>
							<div class="faq-item">
                                <div class="faq-title">
                                    <h6 class="title">Easy to Share Company Brochure.</h6>
                                    <span class="right-icon"></span>
                                </div>
                                <div class="faq-content">
                                    <p>you are able to upload PDF document in your Card. So by that document you can share your company brochure or others documents to clients.</p>
                                </div>
                            </div>
							<div class="faq-item">
                                <div class="faq-title">
                                    <h6 class="title">One Touch Enquary</h6>
                                    <span class="right-icon"></span>
                                </div>
                                <div class="faq-content">
                                    <p>enquary or Feedback field available in your Biz Card.</p>
                                </div>
                            </div>
							<div class="faq-item">
                                <div class="faq-title">
                                    <h6 class="title">WhatsApp Conversation without save number.</h6>
                                    <span class="right-icon"></span>
                                </div>
                                <div class="faq-content">
                                    <p>One Touch Whatsapp contact can make easy to your clients to make conversation without saving your number</p>
                                </div>
                            </div>
							<a href="digi-card-price.php"target="blank" class="custom-button">Check Price Details</a>
                        </div>
                        
						</div>
                    </div>
                </div>
                
            </div>
    </section>
    <!--=================features-End================= -->

    <!--=================Footer Section================= -->
    <footer>
        <div class="footer-top padding-top padding-bottom">
            <div class="container">
                <div class="row mb-50-none">
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Services</h5>
                            <ul>
                                <li>
                                    <a href="domain-register.php">Register Domain</a>
                                </li>
                                <li>
                                    <a href="shared-hosting.php">Shared Hosting</a>
                                </li>
                                <li>
                                    <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                </li>
                                <li>
                                    <a href="bulk-sms.php">Bulk SMS</a>
                                </li>
                                <li>
                                    <a href="web-design-package.php">Web Design Packages</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Company Info</h5>
                            <ul>
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
								<li>
                                    <a href="privacy.php">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="bank.php">Payment Gateway</a>
                                </li>
                                <li>
                                    <a href="faq.php">FAQ</a>
                                </li>
                                <li>
                                    <a href="http://tawk.to/techpmk"target="blank">Support</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Contact</h5>
                            <ul>
                                <li>
                                    <a href="tel:+919476304518">Call : +91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="http://wa.me/919476304518">Whatsapp : +91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="mailto:support@techpmk">Mail : support@techpmk.in</a>
                                </li>	
								<li>
                                    <a href="https://tawk.to/techpmk"target="blank">Live Chat</a>
                                </li>
								<li>
                                    <a href="https://techpmk.onlineinvoices.com/"target="blank">Login to Billing Section</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-about">
                            <h5 class="title">about us</h5>
                            <p align="justify">Tech PMK is the web & graphic designing Organization of India, doing world-class IT solutions. </p>
                            <ul class="footer-social">
                                <li>
                                    <a href="http://www.facebook.com/techpmk"target="blank"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.twitter.com/techpmk"target="blank"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#0"><i class="fab fa-instagram"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.skype.com/techpmk"target="blank"><i class="fab fa-skype"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom py-3 py-sm-4 text-center">
            <div class="container">
                <p class="m-0"> <a href="index.php"><i class="fa fa-copyright"></i> 2020 - All right reserved. | Tech PMK - World Class IT Solutions</a></p>
            </div>
        </div>
    </footer>
    <!--=================Footer Section================= -->
	<!-- ================ Start WhatsApp Widget ================= -->

<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+919476304518", // WhatsApp number
            call_to_action: "Whatsapp us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>

<!-- ================ End WhatsApp Widget ================= -->

    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/waypoint.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/lightcase.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/counterup.min.js"></script>
    <script src="assets/js/nice-select.js"></script>
    <script src="assets/js/main.js"></script>
</body>


<!-- about.php   03:24:41 GMT -->
</html>