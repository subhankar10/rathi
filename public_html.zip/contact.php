<!DOCTYPE html>
<html lang="en">


<!-- contact.php   03:28:55 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/flaticon.css">
    <link rel="stylesheet" href="assets/css/lightcase.css">
    <link rel="stylesheet" href="assets/css/swiper.min.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/main.css">

    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/x-icon">

    <title>Contact Us | Tech PMK - World Class IT Solutions</title>
	<meta name="keywords" content="IT Solutions for - Web Designing, Website Designing, TECHPMK, Tech PMK, Shared Hosting, Linux Unlimited Hosting, Hosting,  Domain Registration, Bulk SMS and Many More">
    <meta name="description" content="IT Solutions for - Web Designing, Shared Hosting, Domain Registration, Bulk SMS and Many More">
    <meta name="author" content="Tech PMK">



</head>

<body>
    <!-- ==========Preloader========== -->
    <div class="preloader">
        <div class="preloader-wrapper">
            <img src="assets/css/ajax-loader.gif" alt="ajax-loader">
        </div>
    </div>
    <!-- ==========Preloader========== -->
    <!-- ==========scrolltotop========== -->
    <a href="#0" class="scrollToTop">
        <img src="assets/images/rocket.png" alt="rocket">
    </a>
    <!-- ==========scrolltotop========== -->

    <!-- ==========Header Section========== -->
    <header>
        <div class="header-top d-none d-md-block bg-theme">
            <div class="container">
                <div class="header-top-wrapper">
                    <div class="row">
                        <div class="col-md-8">
                            <ul>
                                <li class="mr-3">
                                    <a href="Tel:+919476304518"><i class="fa fa-phone-square"></i>+91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="mailto:support@techpmk.in"><i class="fas fa-envelope"></i>support@techpmk.in</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-md-4 d-flex flex-wrap align-items-center justify-content-end">
                            <ul class="social">
                                <li>
                                    <a href="http://www.facebook.com/techpmk">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
								<li>
                                    <a href="https://wa.me/919476304518?text=Hello%2C%20I%20am%20from%20TECHPMK.IN%20-">
                                        <i class="fab fa-whatsapp"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="http://www.twitter.com/techpmk">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                </li>
                            </ul>
                           
					   </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom">
            <div class="container">
                <div class="header-area">
                    <div class="logo">
                        <a href="index.php"><img src="assets/images/logo/logo01.png" alt="logo"></a>
                    </div>
                    <ul class="menu">
					<li>
                            <a href="index.php">Home</a>
                    </li>
						<li>
                            <a href="#0">company Info</a>
                            <ul class="submenu">
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
                                                             
                                <li>
                                    <a href="team.php">Our Team</a>
                                </li>
								
								<li>
                                    <a href="bank.php">Bank Details</a>
                                </li>
								
								<li>
                                    <a href="testimonial.php">Testimonials</a>
                                </li>

								<li>
                                    <a href="#0">Carrier</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="carrier.php">Carrier Oppourtunity</a>
                                        </li>
										
										<li>
                                            <a href="carrrier-registration.php">Registration</a>
                                        </li>
                                                             </ul>
                                </li>								
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Domain</a>
                            <ul class="submenu">
                                <li>
                                    <a href="domain-register.php">Register Domain</a>
                                </li>
                                                             
                                <li>
                                    <a href="domain-transfer.php">Transfer Domain</a>
                                </li>
								<li>
                                    <a href="domain-price.php">Domain Price List</a>
                                </li>
							</ul>
                        </li>
						
						
						<li>
                            <a href="#0">Hosting</a>
                            <ul class="submenu">
                                <li>
                                    <a href="shared-hosting.php">Shared Hosting</a>
                                </li>
                                <li>
                                    <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                </li>
                                <li>
                                    <a href="reseller-hosting.php">Reseller Hosting</a>
                                </li>
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Bulk SMS</a>
                            <ul class="submenu">
                                <li>
                                    <a href="bulk-sms.php">Bulk SMS</a>
                                </li>
                                <li>
                                    <a href="sms-price.php">SMS Price List</a>
                                </li>
								<li>
                                    <a href="http://www.sms.techpmk.in"target="blank">SMS Panel Login</a>
                                </li>
								<li>
                                    <a href="sms-registration.php">SMS Registration</a>
                                </li>
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">Services</a>
                            <ul class="submenu">
                                <li>
                                    <a href="services.php">All Services</a>
                                </li>
                                <li>
                                    <a href="web-design.php">Website Design </a>
                                </li>
                                <li>
                                    <a href="web-development.php">Website Development</a>
                                </li>
                                <li>
                                    <a href="ecommerce.php">e Commerce Website</a>
                                </li>
								<li>
                                    <a href="software.php">Software Development</a>
                                </li>
								<li>
                                    <a href="android.php">Android Application</a>
                                </li>
								<li>
                                    <a href="#0">SEO</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="seo.php">SEO</a>
                                        </li>
										
										<li>
                                            <a href="guest-posting.php">Guest Posting</a>
                                        </li>
										<li>
                                            <a href="sem.php">SEM</a>
                                        </li>
										
                                    </ul>
                                </li>
                                <li>
                                    <a href="#0">Domain</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="domain-register.php">Resigster a Domain</a>
                                        </li>
										
										<li>
                                            <a href="domain-transfer.php">Transfer a Domain</a>
                                        </li>
										<li>
                                            <a href="domain-price.php">Domain Price List</a>
                                        </li>
                                    </ul>
                                </li>
								<li>
                                    <a href="#0">Hosting</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="shared-hosting.php">Shared Hosting</a>
                                        </li>
										
										<li>
                                            <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                        </li>
										<li>
                                            <a href="reseller-hosting.php">Reseller Hosting</a>
                                        </li>
                                    </ul>
                                </li>	
								<li>
                                    <a href="#0">Bulk SMS</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="bulk-sms.php">Bulk SMS</a>
                                        </li>
										
										<li>
                                            <a href="sms-price.php">SMS Price</a>
                                        </li>
								    </ul>
                                </li>
									<li>
                                    <a href="#0">Digi Biz Card</a>
                                    <ul class="submenu">
                                        <li>
                                            <a href="digi-card.php">Digital Biz Card</a>
                                        </li>
										
										<li>
                                            <a href="digi-card-price.php">Price List</a>
                                        </li>
									</ul>
                                </li>								
                            </ul>
                        </li>
						
						<li>
                            <a href="#0">My Digi Card</a>
                            <ul class="submenu">
                                <li>
                                    <a href="digi-card.php">About Digi Card</a>
                                </li>
                                <li>
                                    <a href="digi-card-price.php">Price List</a>
                                </li>
								
                            </ul>
                        </li>
						
						
                        
						
						<li>
                            <a href="#0">Packages</a>
                            <ul class="submenu">
                                <li>
                                    <a href="web-design-package.php">Web Design Packages</a>
                                </li>
                                <li>
                                    <a href="logo-desig-package.php">Logo Design Packages</a>
                                </li>
							</ul>
                        </li>
					
						<li>
                            <a href="contact.php">contact</a>
                        </li>
                    </ul>
                    <div class="header-bar d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                   
                           
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ==========Header Section========== -->

    <!-- =============Hero Area============= -->
    <section class="hero-area bg_img" data-background="assets/images/page-header.jpg">
        <div class="container">
            <h1 class="title m-0">my account</h1>
        </div>
    </section>
    <div class="breadcrumb-section">
        <div class="container">
            <ul class="breadcrumb">
                <li>
                    <a href="index.php">Home</a>
                </li>
                <li>
                    Contact Us
                </li>
            </ul>
        </div>
    </div>
    <!-- =============Hero Area============= -->

    <!--=================Account Section================= -->
    <section class="account-section padding-top padding-bottom bg_img bg_bottom_center bg_contain"
        data-background="assets/images/contact/contact-bg.png">
        <div class="container">
            <div class="account-wrapper">
                <div class="account-area">
                    <h3 class="account-title">send us a message</h3>
                    <form class="contact-form" id="contact_form_submit">
                        <div class="form-group">
                            <input type="text" id="name" placeholder="Full Name">
                        </div>
                        <div class="form-group">
                            <input type="text" id="email" placeholder="Email">
                        </div>
						<div class="form-group">
                            <input type="number" id="mobile" placeholder="Mobile Number">
                        </div>
                        <div class="form-group">
                            <textarea id="message" placeholder="Message"></textarea>
                        </div>
                        <div class="form-group radio-group">
                            <p>Preferred of mode Communication</p>
                            <div class="radio-item">
                                <input type="radio" checked name="mode" id="mode01">
                                <label for="mode01">Email</label>
                            </div>
                            <div class="radio-item">
                                <input type="radio" name="mode" id="mode02">
                                <label for="mode02">Mobile</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Send Message">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!--=================Account Section================= -->
    
    <!--=================Contact Info Section================= -->
    <section class="office-info padding-top padding-bottom">
        <div class="container">
            <div class="section-header">
                <h2 class="title">
                    office contact info
                </h2>
            </div>
            <div class="row justify-content-center mb-30-none">
                <div class="col-md-6 col-sm-10 col-lg-4">
                    <div class="contact-item">
                        <div class="contact-thumb">
                            <!-- <img src="./assets/images/contact/destination.png" alt="contact"> -->
                            <i class="flaticon-route"></i>
                        </div>
                        <div class="contact-content">
                            <h4 class="title">office address</h4>
                            <ul>
                                <li>888/749/9, Natundihi</li>
                                <li>Jhargram, 721507,WB,IN</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-10 col-lg-4">
                    <div class="contact-item">
                        <div class="contact-thumb">
                            <!-- <img src="./assets/images/contact/call.png" alt="contact"> -->
                            <i class="flaticon-call-center"></i>
                        </div>
                        <div class="contact-content">
                            <h4 class="title">phone number</h4>
                            <ul>
                                <li><a href="Tel:9476304518">+91 9476304518</a></li>
                                <li><a href="Tel:03221255048">03221255048</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-10 col-lg-4">
                    <div class="contact-item">
                        <div class="contact-thumb">
                            <!-- <img src="./assets/images/contact/worldwide.png" alt="contact"> -->
                            <i class="flaticon-global"></i>
                        </div>
                        <div class="contact-content">
                            <h4 class="title">Email ID</h4>
                            <ul>
                                <li>
                                    <a href="Mailto:support@techpmk.in">support@techpmk.in</a>
                                </li>
                                <li>
                                    <a href="Mailto:sales@techpmk.in">sales@techpmk.in</a>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
			
                
            </div>
        </div>
    </section>
    <!--=================Contact Info Section================= -->

    <!--=================Maps Section================= -->
   	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3687.240565799189!2d86.98970151427152!3d22.457592442843293!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a1d7b5de2f010d3%3A0x6c2e0741a1235d24!2sTechPMK!5e0!3m2!1sen!2sin!4v1587630883671!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    <!--=================Maps Section================= -->

    <!--=================Footer Section================= -->
    <footer>
        <div class="footer-top padding-top padding-bottom">
            <div class="container">
                <div class="row mb-50-none">
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Services</h5>
                            <ul>
                                <li>
                                    <a href="domain-register.php">Register Domain</a>
                                </li>
                                <li>
                                    <a href="shared-hosting.php">Shared Hosting</a>
                                </li>
                                <li>
                                    <a href="unlimited-hosting.php">Unlimited Hosting</a>
                                </li>
                                <li>
                                    <a href="bulk-sms.php">Bulk SMS</a>
                                </li>
                                <li>
                                    <a href="web-design-package.php">Web Design Packages</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Company Info</h5>
                            <ul>
                                <li>
                                    <a href="about.php">About Us</a>
                                </li>
								<li>
                                    <a href="privacy.php">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="bank.php">Payment Gateway</a>
                                </li>
                                <li>
                                    <a href="faq.php">FAQ</a>
                                </li>
                                <li>
                                    <a href="http://tawk.to/techpmk"target="blank">Support</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-link">
                            <h5 class="title">Contact</h5>
                            <ul>
                                <li>
                                    <a href="tel:+919476304518">Call : +91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="http://wa.me/919476304518">Whatsapp : +91 9476 304 518</a>
                                </li>
                                <li>
                                    <a href="mailto:support@techpmk">Mail : support@techpmk.in</a>
                                </li>	
								<li>
                                    <a href="https://tawk.to/techpmk"target="blank">Live Chat</a>
                                </li>
								<li>
                                    <a href="https://techpmk.onlineinvoices.com/"target="blank">Login to Billing Section</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-widget footer-about">
                            <h5 class="title">about us</h5>
                            <p align="justify">Tech PMK is the web & graphic designing Organization of India, doing world-class IT solutions. </p>
                            <ul class="footer-social">
                                <li>
                                    <a href="http://www.facebook.com/techpmk"target="blank"><i class="fab fa-facebook-f"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.twitter.com/techpmk"target="blank"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#0"><i class="fab fa-instagram"></i></a>
                                </li>
                                <li>
                                    <a href="http://www.skype.com/techpmk"target="blank"><i class="fab fa-skype"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom py-3 py-sm-4 text-center">
            <div class="container">
                <p class="m-0"> <a href="index.php"><i class="fa fa-copyright"></i> 2020 - All right reserved. | Tech PMK - World Class IT Solutions</a></p>
            </div>
        </div>
    </footer>
    <!--=================Footer Section================= -->
	<!-- ================ Start WhatsApp Widget ================= -->

<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+919476304518", // WhatsApp number
            call_to_action: "Whatsapp us", // Call to action
            position: "left", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>

<!-- ================ End WhatsApp Widget ================= -->

    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/waypoint.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/lightcase.js"></script>
    <script src="assets/js/swiper.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/countdown.min.js"></script>
    <script src="assets/js/counterup.min.js"></script>
    <script src="assets/js/nice-select.js"></script>
    <script src="assets/js/contact.js"></script>
    <script src="http://maps.google.com/maps/api/js?key=AIzaSyCo_pcAdFNbTDCAvMwAD19oRTuEmb9M50c"></script>
    <script src="assets/js/map.js"></script>
    <script src="assets/js/main.js"></script>
</body>


<!-- contact.php   03:29:00 GMT -->
</html>